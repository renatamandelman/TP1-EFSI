
  function validarCampo(campo){
   var notaMatematica =  document.getElementById('nota-matematica').value;
   var notaLengua = document.getElementById('nota-lengua').value;
   var notaEfsi = document.getElementById('nota-efsi').value;
  
    if((notaMatematica == "" || notaMatematica > 10 || notaMatematica < 1) || (notaLengua == "" || notaLengua > 10 || notaLengua < 1 ) || (notaEfsi == "" || notaEfsi > 10 || notaEfsi < 1)) 
    {
     // notaMatematica.style.backgroundColor="red";
      alert('Debes escribir un numero del 1 al 10');
      return false;
    }
    else{
      //document.getElementById(materia).style.color="green";

       return true;
    }
   

    
}


function obtenerPromedio(){

   var notaMatematica =  document.getElementById('nota-matematica').value;
   var notaLengua = document.getElementById('nota-lengua').value;
   var notaEfsi = document.getElementById('nota-efsi').value;

   if(validarCampo() == true ) {
   var Promedio =(parseFloat(notaMatematica) + parseFloat(notaEfsi) + parseFloat(notaLengua))/3;
   document.getElementById("Promedio").innerHTML=Promedio;
   }
   if(Promedio >= 6) {
      document.getElementById("Promedio").style.color="green";

   }
   else{
      document.getElementById("Promedio").style.color = "red";

}
   
}

function obtenerMateria(){
   var Materia;
   if(notaMatematica>notaEfsi && notaMatematica>notaLengua){
  Materia = "La materia con mejor nota fue matematica";
  document.getElementById("Materia").innerHTML=Materia;}
   else if(notaLengua>notaMatematica && notaLengua>notaEfsi){
      Materia = "La materia con mejor nota fue lengua"
      document.getElementById("Materia").innerHTML=Materia;;
   }
   else{
      Materia = "La materia con mejor nota fue Efsi";
      document.getElementById("Materia").innerHTML=Materia;
   }
  // document.getElementById("Materia").innerHTML=Materia;


}